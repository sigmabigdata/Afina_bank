--
-- PostgreSQL database dump
--

\restrict hyR9BRb9QgD0JG38basF7olCqCiWUmNQ6kCQzvMHVXsHDMxscHB52I6lBxae6zM

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.documents (
    id bigint NOT NULL,
    original_name character varying(500) NOT NULL,
    stored_name character varying(500) NOT NULL,
    content_type character varying(200),
    size bigint DEFAULT 0 NOT NULL,
    file_sha256 character varying(64),
    signature_base64 text,
    signed boolean DEFAULT false NOT NULL,
    signed_at timestamp with time zone,
    signer_subject character varying(500),
    signer_serial character varying(100),
    uploaded_at timestamp with time zone DEFAULT now() NOT NULL,
    owner_id bigint NOT NULL
);


ALTER TABLE public.documents OWNER TO app_user;

--
-- Name: TABLE documents; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON TABLE public.documents IS 'Загруженные документы';


--
-- Name: COLUMN documents.signature_base64; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON COLUMN public.documents.signature_base64 IS 'Отсоединённая подпись CAdES-BES, Base64';


--
-- Name: COLUMN documents.signed; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON COLUMN public.documents.signed IS 'True — подписан УКЭП';


--
-- Name: COLUMN documents.signer_subject; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON COLUMN public.documents.signer_subject IS 'CN подписанта (ФИО)';


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_id_seq OWNER TO app_user;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


ALTER TABLE public.flyway_schema_history OWNER TO app_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    phone character varying(50),
    role character varying(30) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    login_token character varying(128),
    login_token_expires timestamp with time zone,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO app_user;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON TABLE public.users IS 'Пользователи: клиенты и администраторы';


--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON COLUMN public.users.role IS 'ROLE_USER | ROLE_ADMIN';


--
-- Name: COLUMN users.enabled; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON COLUMN public.users.enabled IS 'False — заблокирован';


--
-- Name: COLUMN users.login_token; Type: COMMENT; Schema: public; Owner: app_user
--

COMMENT ON COLUMN public.users.login_token IS 'Одноразовый токен для входа (magic-link)';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: app_user
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO app_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.documents (id, original_name, stored_name, content_type, size, file_sha256, signature_base64, signed, signed_at, signer_subject, signer_serial, uploaded_at, owner_id) FROM stdin;
\.


--
-- Data for Name: flyway_schema_history; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.flyway_schema_history (installed_rank, version, description, type, script, checksum, installed_by, installed_on, execution_time, success) FROM stdin;
1	1	init	SQL	V1__init.sql	341734528	app_user	2026-09-24 10:22:18.395706	16	t
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public.users (id, email, full_name, phone, role, enabled, login_token, login_token_expires, last_login_at, created_at) FROM stdin;
\.


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app_user
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- Name: idx_documents_owner; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_documents_owner ON public.documents USING btree (owner_id);


--
-- Name: idx_documents_signed; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_documents_signed ON public.documents USING btree (signed);


--
-- Name: idx_documents_uploaded; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_documents_uploaded ON public.documents USING btree (uploaded_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_users_email ON public.users USING btree (lower((email)::text));


--
-- Name: idx_users_login_token; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_users_login_token ON public.users USING btree (login_token);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: documents documents_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO afina_migrator;
GRANT USAGE ON SCHEMA public TO afina_app;
GRANT USAGE ON SCHEMA public TO afina_auditor;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: afina_migrator
--

ALTER DEFAULT PRIVILEGES FOR ROLE afina_migrator IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO afina_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: afina_migrator
--

ALTER DEFAULT PRIVILEGES FOR ROLE afina_migrator IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO afina_app;
ALTER DEFAULT PRIVILEGES FOR ROLE afina_migrator IN SCHEMA public GRANT SELECT ON TABLES TO afina_auditor;


--
-- PostgreSQL database dump complete
--

\unrestrict hyR9BRb9QgD0JG38basF7olCqCiWUmNQ6kCQzvMHVXsHDMxscHB52I6lBxae6zM

